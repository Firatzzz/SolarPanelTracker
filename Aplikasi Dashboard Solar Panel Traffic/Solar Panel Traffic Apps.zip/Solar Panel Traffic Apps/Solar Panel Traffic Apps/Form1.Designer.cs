﻿namespace SolarTrackerDashboard
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblSubtitle = new System.Windows.Forms.Label();
            this.panelVoltage = new System.Windows.Forms.Panel();
            this.lblRawAdcValue = new System.Windows.Forms.Label();
            this.lblRawAdcLabel = new System.Windows.Forms.Label();
            this.lblVoltageUnit = new System.Windows.Forms.Label();
            this.lblVoltageValue = new System.Windows.Forms.Label();
            this.lblVoltageTitle = new System.Windows.Forms.Label();
            this.panelLdrSensors = new System.Windows.Forms.Panel();
            this.panelLdrBawah = new System.Windows.Forms.Panel();
            this.lblLdrDownRaw = new System.Windows.Forms.Label();
            this.lblLdrDownStatus = new System.Windows.Forms.Label();
            this.panelLdrAtas = new System.Windows.Forms.Panel();
            this.lblLdrUpRaw = new System.Windows.Forms.Label();
            this.lblLdrUpStatus = new System.Windows.Forms.Label();
            this.panelLdrKanan = new System.Windows.Forms.Panel();
            this.lblLdrRightRaw = new System.Windows.Forms.Label();
            this.lblLdrRightStatus = new System.Windows.Forms.Label();
            this.panelLdrKiri = new System.Windows.Forms.Panel();
            this.lblLdrLeftRaw = new System.Windows.Forms.Label();
            this.lblLdrLeftStatus = new System.Windows.Forms.Label();
            this.lblLdrTitle = new System.Windows.Forms.Label();
            this.panelServoPosition = new System.Windows.Forms.Panel();
            this.lblServoVValue = new System.Windows.Forms.Label();
            this.progressBarServoV = new System.Windows.Forms.ProgressBar();
            this.lblServoVerticalTitle = new System.Windows.Forms.Label();
            this.lblServoHValue = new System.Windows.Forms.Label();
            this.progressBarServoH = new System.Windows.Forms.ProgressBar();
            this.lblServoHorizontalTitle = new System.Windows.Forms.Label();
            this.lblServoTitle = new System.Windows.Forms.Label();
            this.panelLcdSimulation = new System.Windows.Forms.Panel();
            this.lblLcdLine2 = new System.Windows.Forms.Label();
            this.lblLcdLine1 = new System.Windows.Forms.Label();
            this.lblLcdTitle = new System.Windows.Forms.Label();
            this.panelSerialLog = new System.Windows.Forms.Panel();
            this.btnClearLog = new System.Windows.Forms.Button();
            this.btnDisconnect = new System.Windows.Forms.Button();
            this.btnConnect = new System.Windows.Forms.Button();
            this.richTextBoxLog = new System.Windows.Forms.RichTextBox();
            this.lblLogTitle = new System.Windows.Forms.Label();
            this.comboBoxComPorts = new System.Windows.Forms.ComboBox();
            this.lblComPort = new System.Windows.Forms.Label();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.lblBaudRate = new System.Windows.Forms.Label();
            this.comboBoxBaudRate = new System.Windows.Forms.ComboBox();
            this.panelConnection = new System.Windows.Forms.Panel();
            this.panelVoltage.SuspendLayout();
            this.panelLdrSensors.SuspendLayout();
            this.panelLdrBawah.SuspendLayout();
            this.panelLdrAtas.SuspendLayout();
            this.panelLdrKanan.SuspendLayout();
            this.panelLdrKiri.SuspendLayout();
            this.panelServoPosition.SuspendLayout();
            this.panelLcdSimulation.SuspendLayout();
            this.panelSerialLog.SuspendLayout();
            this.panelConnection.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.lblTitle.Location = new System.Drawing.Point(12, 9);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(409, 46);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Solar Tracker Dashboard";
            // 
            // lblSubtitle
            // 
            this.lblSubtitle.AutoSize = true;
            this.lblSubtitle.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSubtitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            this.lblSubtitle.Location = new System.Drawing.Point(16, 55);
            this.lblSubtitle.Name = "lblSubtitle";
            this.lblSubtitle.Size = new System.Drawing.Size(412, 23);
            this.lblSubtitle.TabIndex = 1;
            this.lblSubtitle.Text = "Monitoring sistem pelacak matahari secara real-time";
            // 
            // panelVoltage
            // 
            this.panelVoltage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.panelVoltage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelVoltage.Controls.Add(this.lblRawAdcValue);
            this.panelVoltage.Controls.Add(this.lblRawAdcLabel);
            this.panelVoltage.Controls.Add(this.lblVoltageUnit);
            this.panelVoltage.Controls.Add(this.lblVoltageValue);
            this.panelVoltage.Controls.Add(this.lblVoltageTitle);
            this.panelVoltage.Location = new System.Drawing.Point(20, 90);
            this.panelVoltage.Name = "panelVoltage";
            this.panelVoltage.Size = new System.Drawing.Size(380, 150);
            this.panelVoltage.TabIndex = 2;
            // 
            // lblRawAdcValue
            // 
            this.lblRawAdcValue.AutoSize = true;
            this.lblRawAdcValue.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRawAdcValue.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.lblRawAdcValue.Location = new System.Drawing.Point(120, 105);
            this.lblRawAdcValue.Name = "lblRawAdcValue";
            this.lblRawAdcValue.Size = new System.Drawing.Size(19, 23);
            this.lblRawAdcValue.TabIndex = 4;
            this.lblRawAdcValue.Text = "0";
            // 
            // lblRawAdcLabel
            // 
            this.lblRawAdcLabel.AutoSize = true;
            this.lblRawAdcLabel.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRawAdcLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.lblRawAdcLabel.Location = new System.Drawing.Point(15, 105);
            this.lblRawAdcLabel.Name = "lblRawAdcLabel";
            this.lblRawAdcLabel.Size = new System.Drawing.Size(84, 23);
            this.lblRawAdcLabel.TabIndex = 3;
            this.lblRawAdcLabel.Text = "Raw ADC:";
            // 
            // lblVoltageUnit
            // 
            this.lblVoltageUnit.AutoSize = true;
            this.lblVoltageUnit.Font = new System.Drawing.Font("Segoe UI Semibold", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVoltageUnit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.lblVoltageUnit.Location = new System.Drawing.Point(170, 55);
            this.lblVoltageUnit.Name = "lblVoltageUnit";
            this.lblVoltageUnit.Size = new System.Drawing.Size(34, 37);
            this.lblVoltageUnit.TabIndex = 2;
            this.lblVoltageUnit.Text = "V";
            // 
            // lblVoltageValue
            // 
            this.lblVoltageValue.AutoSize = true;
            this.lblVoltageValue.Font = new System.Drawing.Font("Segoe UI", 28F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVoltageValue.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(99)))), ((int)(((byte)(71)))));
            this.lblVoltageValue.Location = new System.Drawing.Point(10, 40);
            this.lblVoltageValue.Name = "lblVoltageValue";
            this.lblVoltageValue.Size = new System.Drawing.Size(121, 62);
            this.lblVoltageValue.TabIndex = 1;
            this.lblVoltageValue.Text = "0.00";
            // 
            // lblVoltageTitle
            // 
            this.lblVoltageTitle.AutoSize = true;
            this.lblVoltageTitle.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVoltageTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.lblVoltageTitle.Location = new System.Drawing.Point(10, 10);
            this.lblVoltageTitle.Name = "lblVoltageTitle";
            this.lblVoltageTitle.Size = new System.Drawing.Size(157, 28);
            this.lblVoltageTitle.TabIndex = 0;
            this.lblVoltageTitle.Text = "Monitor Voltase";
            // 
            // panelLdrSensors
            // 
            this.panelLdrSensors.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.panelLdrSensors.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelLdrSensors.Controls.Add(this.panelLdrBawah);
            this.panelLdrSensors.Controls.Add(this.panelLdrAtas);
            this.panelLdrSensors.Controls.Add(this.panelLdrKanan);
            this.panelLdrSensors.Controls.Add(this.panelLdrKiri);
            this.panelLdrSensors.Controls.Add(this.lblLdrTitle);
            this.panelLdrSensors.Location = new System.Drawing.Point(20, 250);
            this.panelLdrSensors.Name = "panelLdrSensors";
            this.panelLdrSensors.Size = new System.Drawing.Size(380, 280);
            this.panelLdrSensors.TabIndex = 3;
            // 
            // panelLdrBawah
            // 
            this.panelLdrBawah.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.panelLdrBawah.Controls.Add(this.lblLdrDownRaw);
            this.panelLdrBawah.Controls.Add(this.lblLdrDownStatus);
            this.panelLdrBawah.Location = new System.Drawing.Point(195, 160);
            this.panelLdrBawah.Name = "panelLdrBawah";
            this.panelLdrBawah.Size = new System.Drawing.Size(170, 100);
            this.panelLdrBawah.TabIndex = 4;
            // 
            // lblLdrDownRaw
            // 
            this.lblLdrDownRaw.AutoSize = true;
            this.lblLdrDownRaw.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLdrDownRaw.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            this.lblLdrDownRaw.Location = new System.Drawing.Point(10, 55);
            this.lblLdrDownRaw.Name = "lblLdrDownRaw";
            this.lblLdrDownRaw.Size = new System.Drawing.Size(52, 20);
            this.lblLdrDownRaw.TabIndex = 1;
            this.lblLdrDownRaw.Text = "Raw: 0";
            // 
            // lblLdrDownStatus
            // 
            this.lblLdrDownStatus.AutoSize = true;
            this.lblLdrDownStatus.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLdrDownStatus.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.lblLdrDownStatus.Location = new System.Drawing.Point(10, 15);
            this.lblLdrDownStatus.Name = "lblLdrDownStatus";
            this.lblLdrDownStatus.Size = new System.Drawing.Size(101, 23);
            this.lblLdrDownStatus.TabIndex = 0;
            this.lblLdrDownStatus.Text = "Bawah: N/A";
            // 
            // panelLdrAtas
            // 
            this.panelLdrAtas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.panelLdrAtas.Controls.Add(this.lblLdrUpRaw);
            this.panelLdrAtas.Controls.Add(this.lblLdrUpStatus);
            this.panelLdrAtas.Location = new System.Drawing.Point(15, 160);
            this.panelLdrAtas.Name = "panelLdrAtas";
            this.panelLdrAtas.Size = new System.Drawing.Size(170, 100);
            this.panelLdrAtas.TabIndex = 3;
            // 
            // lblLdrUpRaw
            // 
            this.lblLdrUpRaw.AutoSize = true;
            this.lblLdrUpRaw.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLdrUpRaw.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            this.lblLdrUpRaw.Location = new System.Drawing.Point(10, 55);
            this.lblLdrUpRaw.Name = "lblLdrUpRaw";
            this.lblLdrUpRaw.Size = new System.Drawing.Size(52, 20);
            this.lblLdrUpRaw.TabIndex = 1;
            this.lblLdrUpRaw.Text = "Raw: 0";
            // 
            // lblLdrUpStatus
            // 
            this.lblLdrUpStatus.AutoSize = true;
            this.lblLdrUpStatus.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLdrUpStatus.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.lblLdrUpStatus.Location = new System.Drawing.Point(10, 15);
            this.lblLdrUpStatus.Name = "lblLdrUpStatus";
            this.lblLdrUpStatus.Size = new System.Drawing.Size(83, 23);
            this.lblLdrUpStatus.TabIndex = 0;
            this.lblLdrUpStatus.Text = "Atas: N/A";
            // 
            // panelLdrKanan
            // 
            this.panelLdrKanan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(60)))), ((int)(((byte)(0)))));
            this.panelLdrKanan.Controls.Add(this.lblLdrRightRaw);
            this.panelLdrKanan.Controls.Add(this.lblLdrRightStatus);
            this.panelLdrKanan.Location = new System.Drawing.Point(195, 50);
            this.panelLdrKanan.Name = "panelLdrKanan";
            this.panelLdrKanan.Size = new System.Drawing.Size(170, 100);
            this.panelLdrKanan.TabIndex = 2;
            // 
            // lblLdrRightRaw
            // 
            this.lblLdrRightRaw.AutoSize = true;
            this.lblLdrRightRaw.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLdrRightRaw.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            this.lblLdrRightRaw.Location = new System.Drawing.Point(10, 55);
            this.lblLdrRightRaw.Name = "lblLdrRightRaw";
            this.lblLdrRightRaw.Size = new System.Drawing.Size(52, 20);
            this.lblLdrRightRaw.TabIndex = 1;
            this.lblLdrRightRaw.Text = "Raw: 0";
            // 
            // lblLdrRightStatus
            // 
            this.lblLdrRightStatus.AutoSize = true;
            this.lblLdrRightStatus.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLdrRightStatus.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.lblLdrRightStatus.Location = new System.Drawing.Point(10, 15);
            this.lblLdrRightStatus.Name = "lblLdrRightStatus";
            this.lblLdrRightStatus.Size = new System.Drawing.Size(98, 23);
            this.lblLdrRightStatus.TabIndex = 0;
            this.lblLdrRightStatus.Text = "Kanan: N/A";
            // 
            // panelLdrKiri
            // 
            this.panelLdrKiri.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(70)))), ((int)(((byte)(73)))));
            this.panelLdrKiri.Controls.Add(this.lblLdrLeftRaw);
            this.panelLdrKiri.Controls.Add(this.lblLdrLeftStatus);
            this.panelLdrKiri.Location = new System.Drawing.Point(15, 50);
            this.panelLdrKiri.Name = "panelLdrKiri";
            this.panelLdrKiri.Size = new System.Drawing.Size(170, 100);
            this.panelLdrKiri.TabIndex = 1;
            // 
            // lblLdrLeftRaw
            // 
            this.lblLdrLeftRaw.AutoSize = true;
            this.lblLdrLeftRaw.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLdrLeftRaw.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(200)))));
            this.lblLdrLeftRaw.Location = new System.Drawing.Point(10, 55);
            this.lblLdrLeftRaw.Name = "lblLdrLeftRaw";
            this.lblLdrLeftRaw.Size = new System.Drawing.Size(52, 20);
            this.lblLdrLeftRaw.TabIndex = 1;
            this.lblLdrLeftRaw.Text = "Raw: 0";
            // 
            // lblLdrLeftStatus
            // 
            this.lblLdrLeftStatus.AutoSize = true;
            this.lblLdrLeftStatus.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLdrLeftStatus.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.lblLdrLeftStatus.Location = new System.Drawing.Point(10, 15);
            this.lblLdrLeftStatus.Name = "lblLdrLeftStatus";
            this.lblLdrLeftStatus.Size = new System.Drawing.Size(74, 23);
            this.lblLdrLeftStatus.TabIndex = 0;
            this.lblLdrLeftStatus.Text = "Kiri: N/A";
            // 
            // lblLdrTitle
            // 
            this.lblLdrTitle.AutoSize = true;
            this.lblLdrTitle.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLdrTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.lblLdrTitle.Location = new System.Drawing.Point(10, 10);
            this.lblLdrTitle.Name = "lblLdrTitle";
            this.lblLdrTitle.Size = new System.Drawing.Size(144, 28);
            this.lblLdrTitle.TabIndex = 0;
            this.lblLdrTitle.Text = "Sensor Cahaya";
            // 
            // panelServoPosition
            // 
            this.panelServoPosition.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.panelServoPosition.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelServoPosition.Controls.Add(this.lblServoVValue);
            this.panelServoPosition.Controls.Add(this.progressBarServoV);
            this.panelServoPosition.Controls.Add(this.lblServoVerticalTitle);
            this.panelServoPosition.Controls.Add(this.lblServoHValue);
            this.panelServoPosition.Controls.Add(this.progressBarServoH);
            this.panelServoPosition.Controls.Add(this.lblServoHorizontalTitle);
            this.panelServoPosition.Controls.Add(this.lblServoTitle);
            this.panelServoPosition.Location = new System.Drawing.Point(420, 90);
            this.panelServoPosition.Name = "panelServoPosition";
            this.panelServoPosition.Size = new System.Drawing.Size(487, 200);
            this.panelServoPosition.TabIndex = 4;
            // 
            // lblServoVValue
            // 
            this.lblServoVValue.AutoSize = true;
            this.lblServoVValue.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblServoVValue.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(205)))), ((int)(((byte)(50)))));
            this.lblServoVValue.Location = new System.Drawing.Point(280, 118);
            this.lblServoVValue.Name = "lblServoVValue";
            this.lblServoVValue.Size = new System.Drawing.Size(31, 28);
            this.lblServoVValue.TabIndex = 6;
            this.lblServoVValue.Text = "0°";
            // 
            // progressBarServoV
            // 
            this.progressBarServoV.Location = new System.Drawing.Point(15, 150);
            this.progressBarServoV.Maximum = 180;
            this.progressBarServoV.Name = "progressBarServoV";
            this.progressBarServoV.Size = new System.Drawing.Size(350, 23);
            this.progressBarServoV.TabIndex = 5;
            // 
            // lblServoVerticalTitle
            // 
            this.lblServoVerticalTitle.AutoSize = true;
            this.lblServoVerticalTitle.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblServoVerticalTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.lblServoVerticalTitle.Location = new System.Drawing.Point(15, 120);
            this.lblServoVerticalTitle.Name = "lblServoVerticalTitle";
            this.lblServoVerticalTitle.Size = new System.Drawing.Size(66, 23);
            this.lblServoVerticalTitle.TabIndex = 4;
            this.lblServoVerticalTitle.Text = "Vertical";
            // 
            // lblServoHValue
            // 
            this.lblServoHValue.AutoSize = true;
            this.lblServoHValue.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblServoHValue.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(191)))), ((int)(((byte)(255)))));
            this.lblServoHValue.Location = new System.Drawing.Point(280, 48);
            this.lblServoHValue.Name = "lblServoHValue";
            this.lblServoHValue.Size = new System.Drawing.Size(31, 28);
            this.lblServoHValue.TabIndex = 3;
            this.lblServoHValue.Text = "0°";
            // 
            // progressBarServoH
            // 
            this.progressBarServoH.Location = new System.Drawing.Point(15, 80);
            this.progressBarServoH.Maximum = 180;
            this.progressBarServoH.Name = "progressBarServoH";
            this.progressBarServoH.Size = new System.Drawing.Size(350, 23);
            this.progressBarServoH.TabIndex = 2;
            // 
            // lblServoHorizontalTitle
            // 
            this.lblServoHorizontalTitle.AutoSize = true;
            this.lblServoHorizontalTitle.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblServoHorizontalTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.lblServoHorizontalTitle.Location = new System.Drawing.Point(15, 50);
            this.lblServoHorizontalTitle.Name = "lblServoHorizontalTitle";
            this.lblServoHorizontalTitle.Size = new System.Drawing.Size(89, 23);
            this.lblServoHorizontalTitle.TabIndex = 1;
            this.lblServoHorizontalTitle.Text = "Horizontal";
            // 
            // lblServoTitle
            // 
            this.lblServoTitle.AutoSize = true;
            this.lblServoTitle.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblServoTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.lblServoTitle.Location = new System.Drawing.Point(10, 10);
            this.lblServoTitle.Name = "lblServoTitle";
            this.lblServoTitle.Size = new System.Drawing.Size(121, 28);
            this.lblServoTitle.TabIndex = 0;
            this.lblServoTitle.Text = "Posisi Servo";
            // 
            // panelLcdSimulation
            // 
            this.panelLcdSimulation.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(30)))), ((int)(((byte)(40)))));
            this.panelLcdSimulation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelLcdSimulation.Controls.Add(this.lblLcdLine2);
            this.panelLcdSimulation.Controls.Add(this.lblLcdLine1);
            this.panelLcdSimulation.Controls.Add(this.lblLcdTitle);
            this.panelLcdSimulation.Location = new System.Drawing.Point(420, 300);
            this.panelLcdSimulation.Name = "panelLcdSimulation";
            this.panelLcdSimulation.Size = new System.Drawing.Size(487, 130);
            this.panelLcdSimulation.TabIndex = 5;
            // 
            // lblLcdLine2
            // 
            this.lblLcdLine2.AutoSize = true;
            this.lblLcdLine2.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLcdLine2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(220)))), ((int)(((byte)(120)))));
            this.lblLcdLine2.Location = new System.Drawing.Point(15, 85);
            this.lblLcdLine2.Name = "lblLcdLine2";
            this.lblLcdLine2.Size = new System.Drawing.Size(131, 23);
            this.lblLcdLine2.TabIndex = 2;
            this.lblLcdLine2.Text = "L:N/A R:N/A";
            // 
            // lblLcdLine1
            // 
            this.lblLcdLine1.AutoSize = true;
            this.lblLcdLine1.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLcdLine1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(220)))), ((int)(((byte)(120)))));
            this.lblLcdLine1.Location = new System.Drawing.Point(15, 50);
            this.lblLcdLine1.Name = "lblLcdLine1";
            this.lblLcdLine1.Size = new System.Drawing.Size(197, 23);
            this.lblLcdLine1.TabIndex = 1;
            this.lblLcdLine1.Text = "VOLT:0.00 H:0 V:0";
            // 
            // lblLcdTitle
            // 
            this.lblLcdTitle.AutoSize = true;
            this.lblLcdTitle.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLcdTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.lblLcdTitle.Location = new System.Drawing.Point(10, 10);
            this.lblLcdTitle.Name = "lblLcdTitle";
            this.lblLcdTitle.Size = new System.Drawing.Size(174, 28);
            this.lblLcdTitle.TabIndex = 0;
            this.lblLcdTitle.Text = "Simulasi LCD 16x2";
            // 
            // panelSerialLog
            // 
            this.panelSerialLog.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.panelSerialLog.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelSerialLog.Controls.Add(this.btnClearLog);
            this.panelSerialLog.Controls.Add(this.btnDisconnect);
            this.panelSerialLog.Controls.Add(this.btnConnect);
            this.panelSerialLog.Controls.Add(this.richTextBoxLog);
            this.panelSerialLog.Controls.Add(this.lblLogTitle);
            this.panelSerialLog.Location = new System.Drawing.Point(20, 540);
            this.panelSerialLog.Name = "panelSerialLog";
            this.panelSerialLog.Size = new System.Drawing.Size(887, 220);
            this.panelSerialLog.TabIndex = 6;
            // 
            // btnClearLog
            // 
            this.btnClearLog.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            this.btnClearLog.FlatAppearance.BorderSize = 0;
            this.btnClearLog.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClearLog.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearLog.ForeColor = System.Drawing.Color.White;
            this.btnClearLog.Location = new System.Drawing.Point(764, 170);
            this.btnClearLog.Name = "btnClearLog";
            this.btnClearLog.Size = new System.Drawing.Size(100, 35);
            this.btnClearLog.TabIndex = 4;
            this.btnClearLog.Text = "Clear Log";
            this.btnClearLog.UseVisualStyleBackColor = false;
            this.btnClearLog.Click += new System.EventHandler(this.BtnClearLog_Click);
            // 
            // btnDisconnect
            // 
            this.btnDisconnect.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(205)))), ((int)(((byte)(92)))), ((int)(((byte)(92)))));
            this.btnDisconnect.Enabled = false;
            this.btnDisconnect.FlatAppearance.BorderSize = 0;
            this.btnDisconnect.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDisconnect.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDisconnect.ForeColor = System.Drawing.Color.White;
            this.btnDisconnect.Location = new System.Drawing.Point(653, 170);
            this.btnDisconnect.Name = "btnDisconnect";
            this.btnDisconnect.Size = new System.Drawing.Size(100, 35);
            this.btnDisconnect.TabIndex = 3;
            this.btnDisconnect.Text = "Stop";
            this.btnDisconnect.UseVisualStyleBackColor = false;
            this.btnDisconnect.Click += new System.EventHandler(this.BtnDisconnect_Click);
            // 
            // btnConnect
            // 
            this.btnConnect.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.btnConnect.FlatAppearance.BorderSize = 0;
            this.btnConnect.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConnect.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConnect.ForeColor = System.Drawing.Color.White;
            this.btnConnect.Location = new System.Drawing.Point(507, 170);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(140, 35);
            this.btnConnect.TabIndex = 2;
            this.btnConnect.Text = "Mulai Simulasi";
            this.btnConnect.UseVisualStyleBackColor = false;
            this.btnConnect.Click += new System.EventHandler(this.BtnConnect_Click);
            // 
            // richTextBoxLog
            // 
            this.richTextBoxLog.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.richTextBoxLog.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBoxLog.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBoxLog.ForeColor = System.Drawing.Color.LightGray;
            this.richTextBoxLog.Location = new System.Drawing.Point(15, 45);
            this.richTextBoxLog.Name = "richTextBoxLog";
            this.richTextBoxLog.ReadOnly = true;
            this.richTextBoxLog.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.richTextBoxLog.Size = new System.Drawing.Size(849, 115);
            this.richTextBoxLog.TabIndex = 1;
            this.richTextBoxLog.Text = "";
            // 
            // lblLogTitle
            // 
            this.lblLogTitle.AutoSize = true;
            this.lblLogTitle.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.lblLogTitle.Location = new System.Drawing.Point(10, 10);
            this.lblLogTitle.Name = "lblLogTitle";
            this.lblLogTitle.Size = new System.Drawing.Size(148, 28);
            this.lblLogTitle.TabIndex = 0;
            this.lblLogTitle.Text = "Log Data Serial";
            // 
            // comboBoxComPorts
            // 
            this.comboBoxComPorts.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(63)))));
            this.comboBoxComPorts.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxComPorts.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBoxComPorts.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxComPorts.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.comboBoxComPorts.FormattingEnabled = true;
            this.comboBoxComPorts.Location = new System.Drawing.Point(110, 10);
            this.comboBoxComPorts.Name = "comboBoxComPorts";
            this.comboBoxComPorts.Size = new System.Drawing.Size(120, 28);
            this.comboBoxComPorts.TabIndex = 7;
            // 
            // lblComPort
            // 
            this.lblComPort.AutoSize = true;
            this.lblComPort.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblComPort.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.lblComPort.Location = new System.Drawing.Point(10, 12);
            this.lblComPort.Name = "lblComPort";
            this.lblComPort.Size = new System.Drawing.Size(89, 23);
            this.lblComPort.TabIndex = 8;
            this.lblComPort.Text = "COM Port:";
            // 
            // serialPort1
            // 
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.SerialPort1_DataReceived);
            // 
            // lblBaudRate
            // 
            this.lblBaudRate.AutoSize = true;
            this.lblBaudRate.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBaudRate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.lblBaudRate.Location = new System.Drawing.Point(250, 12);
            this.lblBaudRate.Name = "lblBaudRate";
            this.lblBaudRate.Size = new System.Drawing.Size(92, 23);
            this.lblBaudRate.TabIndex = 9;
            this.lblBaudRate.Text = "Baud Rate:";
            // 
            // comboBoxBaudRate
            // 
            this.comboBoxBaudRate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(63)))));
            this.comboBoxBaudRate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxBaudRate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBoxBaudRate.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxBaudRate.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.comboBoxBaudRate.FormattingEnabled = true;
            this.comboBoxBaudRate.Items.AddRange(new object[] {
            "9600",
            "19200",
            "38400",
            "57600",
            "115200"});
            this.comboBoxBaudRate.Location = new System.Drawing.Point(350, 10);
            this.comboBoxBaudRate.Name = "comboBoxBaudRate";
            this.comboBoxBaudRate.Size = new System.Drawing.Size(120, 28);
            this.comboBoxBaudRate.TabIndex = 10;
            // 
            // panelConnection
            // 
            this.panelConnection.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.panelConnection.Controls.Add(this.lblComPort);
            this.panelConnection.Controls.Add(this.comboBoxBaudRate);
            this.panelConnection.Controls.Add(this.comboBoxComPorts);
            this.panelConnection.Controls.Add(this.lblBaudRate);
            this.panelConnection.Location = new System.Drawing.Point(420, 440);
            this.panelConnection.Name = "panelConnection";
            this.panelConnection.Size = new System.Drawing.Size(487, 90);
            this.panelConnection.TabIndex = 11;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.ClientSize = new System.Drawing.Size(937, 773);
            this.Controls.Add(this.panelConnection);
            this.Controls.Add(this.panelSerialLog);
            this.Controls.Add(this.panelLcdSimulation);
            this.Controls.Add(this.panelServoPosition);
            this.Controls.Add(this.panelLdrSensors);
            this.Controls.Add(this.panelVoltage);
            this.Controls.Add(this.lblSubtitle);
            this.Controls.Add(this.lblTitle);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(220)))));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Solar Tracker Dashboard - Dark Mode";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panelVoltage.ResumeLayout(false);
            this.panelVoltage.PerformLayout();
            this.panelLdrSensors.ResumeLayout(false);
            this.panelLdrSensors.PerformLayout();
            this.panelLdrBawah.ResumeLayout(false);
            this.panelLdrBawah.PerformLayout();
            this.panelLdrAtas.ResumeLayout(false);
            this.panelLdrAtas.PerformLayout();
            this.panelLdrKanan.ResumeLayout(false);
            this.panelLdrKanan.PerformLayout();
            this.panelLdrKiri.ResumeLayout(false);
            this.panelLdrKiri.PerformLayout();
            this.panelServoPosition.ResumeLayout(false);
            this.panelServoPosition.PerformLayout();
            this.panelLcdSimulation.ResumeLayout(false);
            this.panelLcdSimulation.PerformLayout();
            this.panelSerialLog.ResumeLayout(false);
            this.panelSerialLog.PerformLayout();
            this.panelConnection.ResumeLayout(false);
            this.panelConnection.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblSubtitle;
        private System.Windows.Forms.Panel panelVoltage;
        private System.Windows.Forms.Label lblVoltageValue;
        private System.Windows.Forms.Label lblVoltageTitle;
        private System.Windows.Forms.Label lblVoltageUnit;
        private System.Windows.Forms.Label lblRawAdcValue;
        private System.Windows.Forms.Label lblRawAdcLabel;
        private System.Windows.Forms.Panel panelLdrSensors;
        private System.Windows.Forms.Label lblLdrTitle;
        private System.Windows.Forms.Panel panelLdrKiri;
        private System.Windows.Forms.Label lblLdrLeftStatus;
        private System.Windows.Forms.Label lblLdrLeftRaw;
        private System.Windows.Forms.Panel panelLdrBawah;
        private System.Windows.Forms.Label lblLdrDownRaw;
        private System.Windows.Forms.Label lblLdrDownStatus;
        private System.Windows.Forms.Panel panelLdrAtas;
        private System.Windows.Forms.Label lblLdrUpRaw;
        private System.Windows.Forms.Label lblLdrUpStatus;
        private System.Windows.Forms.Panel panelLdrKanan;
        private System.Windows.Forms.Label lblLdrRightRaw;
        private System.Windows.Forms.Label lblLdrRightStatus;
        private System.Windows.Forms.Panel panelServoPosition;
        private System.Windows.Forms.Label lblServoTitle;
        private System.Windows.Forms.Label lblServoHorizontalTitle;
        private System.Windows.Forms.ProgressBar progressBarServoH;
        private System.Windows.Forms.Label lblServoHValue;
        private System.Windows.Forms.Label lblServoVValue;
        private System.Windows.Forms.ProgressBar progressBarServoV;
        private System.Windows.Forms.Label lblServoVerticalTitle;
        private System.Windows.Forms.Panel panelLcdSimulation;
        private System.Windows.Forms.Label lblLcdTitle;
        private System.Windows.Forms.Label lblLcdLine1;
        private System.Windows.Forms.Label lblLcdLine2;
        private System.Windows.Forms.Panel panelSerialLog;
        private System.Windows.Forms.Label lblLogTitle;
        private System.Windows.Forms.RichTextBox richTextBoxLog;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.Button btnClearLog;
        private System.Windows.Forms.Button btnDisconnect;
        private System.Windows.Forms.ComboBox comboBoxComPorts;
        private System.Windows.Forms.Label lblComPort;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Label lblBaudRate;
        private System.Windows.Forms.ComboBox comboBoxBaudRate;
        private System.Windows.Forms.Panel panelConnection;
    }
}
