﻿using System;
using System.Drawing; // Untuk Color
using System.Globalization; // Untuk CultureInfo.InvariantCulture
using System.IO.Ports;
using System.Linq; // Untuk comboBoxComPorts.SelectedItem
using System.Text.RegularExpressions; // Untuk parsing Regex
using System.Windows.Forms;

namespace SolarTrackerDashboard
{
    public partial class Form1 : Form
    {
        // Variabel untuk menyimpan nilai terakhir agar bisa merekonstruksi tampilan LCD
        private string currentVoltage = "0.00";
        private string currentLdrLeftStatus = "N/A";
        private string currentLdrRightStatus = "N/A";
        // private string currentLdrUpStatus = "N/A"; // Dihapus karena tidak digunakan (IDE0052)
        // private string currentLdrDownStatus = "N/A"; // Dihapus karena tidak digunakan (IDE0052)
        private int currentServoH = 90;
        private int currentServoV = 90;


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadComPorts();
            comboBoxBaudRate.SelectedItem = "9600"; // Default baud rate Arduino
            InitializeUIDefaults();
            // Setel warna default untuk log, karena ForeColor RichTextBox diatur di Designer
            richTextBoxLog.ForeColor = System.Drawing.Color.LightGray;
        }

        private void InitializeUIDefaults()
        {
            // Mengatur nilai default atau placeholder pada UI saat form load
            lblVoltageValue.Text = "0.00";
            lblRawAdcValue.Text = "0";

            lblLdrLeftStatus.Text = "Kiri: N/A";
            lblLdrLeftRaw.Text = "Raw: 0";
            lblLdrRightStatus.Text = "Kanan: N/A";
            lblLdrRightRaw.Text = "Raw: 0";
            lblLdrUpStatus.Text = "Atas: N/A";
            lblLdrUpRaw.Text = "Raw: 0";
            lblLdrDownStatus.Text = "Bawah: N/A";
            lblLdrDownRaw.Text = "Raw: 0";

            progressBarServoH.Value = 90;
            lblServoHValue.Text = "90°";
            progressBarServoV.Value = 90;
            lblServoVValue.Text = "90°";

            UpdateLcdDisplay();
        }


        private void LoadComPorts()
        {
            string[] ports = SerialPort.GetPortNames();
            comboBoxComPorts.Items.Clear();
            if (ports.Length > 0)
            {
                comboBoxComPorts.Items.AddRange(ports);
                comboBoxComPorts.SelectedIndex = 0;
            }
            else
            {
                AppendToLog("Tidak ada COM Port yang terdeteksi.", Color.Salmon); // Warna log disesuaikan
                btnConnect.Enabled = false;
            }
        }

        private void BtnConnect_Click(object sender, EventArgs e)
        {
            if (comboBoxComPorts.SelectedItem == null)
            {
                MessageBox.Show("Silakan pilih COM Port.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (comboBoxBaudRate.SelectedItem == null)
            {
                MessageBox.Show("Silakan pilih Baud Rate.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                serialPort1.PortName = comboBoxComPorts.SelectedItem.ToString();
                serialPort1.BaudRate = int.Parse(comboBoxBaudRate.SelectedItem.ToString());
                serialPort1.Parity = Parity.None;
                serialPort1.DataBits = 8;
                serialPort1.StopBits = StopBits.One;
                serialPort1.Handshake = Handshake.None;
                serialPort1.ReadTimeout = 500;
                serialPort1.WriteTimeout = 500;

                serialPort1.Open();
                AppendToLog($"Terhubung ke {serialPort1.PortName} pada baud rate {serialPort1.BaudRate}.", Color.LightGreen); // Warna log disesuaikan
                btnConnect.Enabled = false;
                btnDisconnect.Enabled = true;
                comboBoxComPorts.Enabled = false;
                comboBoxBaudRate.Enabled = false;
            }
            catch (Exception ex)
            {
                AppendToLog($"Gagal terhubung: {ex.Message}", Color.Salmon); // Warna log disesuaikan
                MessageBox.Show($"Error: {ex.Message}", "Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnDisconnect_Click(object sender, EventArgs e)
        {
            try
            {
                if (serialPort1.IsOpen)
                {
                    serialPort1.Close();
                    AppendToLog("Koneksi ditutup.", Color.Orange); // Warna log disesuaikan
                }
                btnConnect.Enabled = true;
                btnDisconnect.Enabled = false;
                comboBoxComPorts.Enabled = true;
                comboBoxBaudRate.Enabled = true;
            }
            catch (Exception ex)
            {
                AppendToLog($"Error saat menutup koneksi: {ex.Message}", Color.Salmon); // Warna log disesuaikan
            }
        }

        private void BtnClearLog_Click(object sender, EventArgs e)
        {
            richTextBoxLog.Clear();
        }

        private void SerialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                if (serialPort1.IsOpen)
                {
                    string data = serialPort1.ReadLine();
                    this.Invoke(new Action(() => ProcessReceivedData(data)));
                }
            }
            catch (TimeoutException)
            {
                // Abaikan
            }
            catch (Exception ex)
            {
                this.Invoke(new Action(() => AppendToLog($"Error menerima data: {ex.Message}", Color.LightCoral))); // Warna log disesuaikan
            }
        }

        private void ProcessReceivedData(string data)
        {
            data = data.Trim();
            AppendToLog(data, Color.LightGray); // Warna log default untuk data mentah

            try
            {
                if (data.StartsWith("LDRs: U="))
                {
                    Match ldrMatch = Regex.Match(data, @"LDRs: U=(\d+) D=(\d+) L=(\d+) R=(\d+) \| ErrV=([-\d]+) ErrH=([-\d]+) \| dSV=([-\d\.]+) dSH=([-\d\.]+)");
                    if (ldrMatch.Success)
                    {
                        lblLdrUpRaw.Text = $"Raw: {ldrMatch.Groups[1].Value}";
                        lblLdrDownRaw.Text = $"Raw: {ldrMatch.Groups[2].Value}";
                        lblLdrLeftRaw.Text = $"Raw: {ldrMatch.Groups[3].Value}";
                        lblLdrRightRaw.Text = $"Raw: {ldrMatch.Groups[4].Value}";
                    }
                }
                else if (data.StartsWith("Voltage ="))
                {
                    Match voltageMatch = Regex.Match(data, @"Voltage = ([\d\.]+V) \(A5 ADC: (\d+)\)");
                    if (voltageMatch.Success)
                    {
                        string voltageFullString = voltageMatch.Groups[1].Value;
                        currentVoltage = voltageFullString.Replace("V", "");

                        if (float.TryParse(currentVoltage, NumberStyles.Any, CultureInfo.InvariantCulture, out float voltVal))
                        {
                            lblVoltageValue.Text = voltVal.ToString("0.00", CultureInfo.InvariantCulture);
                            currentVoltage = voltVal.ToString("0.00", CultureInfo.InvariantCulture);
                        }
                        else
                        {
                            lblVoltageValue.Text = "Err";
                            currentVoltage = "Err";
                        }
                        lblRawAdcValue.Text = voltageMatch.Groups[2].Value;
                    }
                }
                else if (data.StartsWith("Sensor "))
                {
                    Match sensorMatch = Regex.Match(data, @"Sensor (\w) \(A\d\): (\d+) -> ([\w\s\.]+)");
                    if (sensorMatch.Success)
                    {
                        string sensorName = sensorMatch.Groups[1].Value;
                        string rawValue = sensorMatch.Groups[2].Value;
                        string status = sensorMatch.Groups[3].Value.Trim();

                        if (sensorName == "L") { lblLdrLeftStatus.Text = $"Kiri: {status}"; lblLdrLeftRaw.Text = $"Raw: {rawValue}"; currentLdrLeftStatus = status; }
                        else if (sensorName == "R") { lblLdrRightStatus.Text = $"Kanan: {status}"; lblLdrRightRaw.Text = $"Raw: {rawValue}"; currentLdrRightStatus = status; }
                        else if (sensorName == "U") { lblLdrUpStatus.Text = $"Atas: {status}"; lblLdrUpRaw.Text = $"Raw: {rawValue}"; }
                        else if (sensorName == "D") { lblLdrDownStatus.Text = $"Bawah: {status}"; lblLdrDownRaw.Text = $"Raw: {rawValue}"; }
                    }
                }
                else if (data.StartsWith("SERVO_POS:"))
                {
                    Match servoMatch = Regex.Match(data, @"SERVO_POS:H=(\d+),V=(\d+)");
                    if (servoMatch.Success)
                    {
                        currentServoH = int.Parse(servoMatch.Groups[1].Value);
                        currentServoV = int.Parse(servoMatch.Groups[2].Value);
                        UpdateServoUI();
                    }
                }
                UpdateLcdDisplay();
            }
            catch (Exception ex)
            {
                AppendToLog($"Error parsing data: \"{data}\" - {ex.Message}", Color.SandyBrown); // Warna log disesuaikan
            }
        }

        private void UpdateServoUI()
        {
            if (currentServoH >= progressBarServoH.Minimum && currentServoH <= progressBarServoH.Maximum)
                progressBarServoH.Value = currentServoH;
            lblServoHValue.Text = $"{currentServoH}°";

            if (currentServoV >= progressBarServoV.Minimum && currentServoV <= progressBarServoV.Maximum)
                progressBarServoV.Value = currentServoV;
            lblServoVValue.Text = $"{currentServoV}°";
        }


        private void UpdateLcdDisplay()
        {
            lblLcdLine1.Text = $"VOLT:{currentVoltage} H:{currentServoH} V:{currentServoV}";
            lblLcdLine2.Text = $"L:{currentLdrLeftStatus} R:{currentLdrRightStatus}";
        }


        private void AppendToLog(string message, Color color)
        {
            if (richTextBoxLog.InvokeRequired)
            {
                richTextBoxLog.Invoke(new Action<string, Color>(AppendToLog), message, color);
                return;
            }
            richTextBoxLog.SelectionStart = richTextBoxLog.TextLength;
            richTextBoxLog.SelectionLength = 0;
            richTextBoxLog.SelectionColor = color; // Warna spesifik untuk pesan ini
            richTextBoxLog.AppendText($"[{DateTime.Now.ToLongTimeString()}] {message}{Environment.NewLine}");
            // Tidak perlu reset color ke ForeColor RichTextBox karena setiap AppendToLog mengatur warnanya sendiri.
            richTextBoxLog.ScrollToCaret();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                try
                {
                    serialPort1.Close();
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error closing port on exit: {ex.Message}");
                }
            }
        }
    }
}
